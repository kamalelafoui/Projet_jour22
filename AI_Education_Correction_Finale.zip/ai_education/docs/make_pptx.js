const fs = require("fs");
const pptxgen = require("pptxgenjs");
const { applyTheme } = require("/mnt/skills/public/pptx/scripts/apply_theme.js");
const rep = JSON.parse(fs.readFileSync("reports/report.json", "utf8"));
const THEME = { name: "AI Education", headFontFace: "Calibri", bodyFontFace: "Calibri", colors: {
  dk1: "14213D", lt1: "FFFFFF", dk2: "1F3A5F", lt2: "F4F6FA", accent1: "1F3A5F", accent2: "F2B90F",
  accent3: "E8871E", accent4: "1F9D55", accent5: "D64545", accent6: "2B5FD9", hlink: "2B5FD9", folHlink: "5B6478" } };
const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
pres.title = "AI Education - Tests automatisés & CI/CD agentique";
const C = pres.SchemeColor;
pres.defineSlideMaster({ title: "CONTENT", background: { color: "FFFFFF" },
  objects: [{ rect: { x: 0, y: 0, w: 10, h: 0.12, fill: { color: "F2B90F" } } }],
  slideNumber: { x: 9.2, y: 5.25, w: 0.5, h: 0.25, fontSize: 10, color: "5B6478" },
});
pres.defineSlideMaster({ title: "TITLE", background: { color: "1F3A5F" } });

// 1. titre
let s = pres.addSlide({ masterName: "TITLE" });
s.addShape(pres.ShapeType.rect, { x: 0.6, y: 1.5, w: 0.12, h: 1.6, fill: { color: C.accent2 }, line: { color: C.accent2 } });
s.addImage({ path: "assets/logo_icon.png", x: 0.95, y: 0.45, w: 0.8, h: 0.8, altText: "Logo AI Education" });
s.addText("AI Education", { x: 0.95, y: 1.4, w: 8, h: 0.9, fontSize: 44, bold: true, color: "FFFFFF", isTextBox: true, margin: 0 });
s.addText("Tests automatisés & CI/CD agentique", { x: 0.95, y: 2.3, w: 8, h: 0.6, fontSize: 24, color: "F2B90F", isTextBox: true, margin: 0 });
s.addText("Mini-projet — Correction finale · Jour 22", { x: 0.95, y: 3.0, w: 8, h: 0.4, fontSize: 16, color: "DDE4F2", isTextBox: true, margin: 0 });
s.addNotes("Objectif du jour : garantir la qualité de l'agent après chaque modification.");

function content(title) { const sl = pres.addSlide({ masterName: "CONTENT" }); sl.addText(title, { x: 0.6, y: 0.35, w: 8.8, h: 0.8, fontSize: 28, bold: true, color: "1F3A5F", isTextBox: true, margin: 0, valign: "middle" }); return sl; }

// 2. pourquoi tester
s = content("Pourquoi tester l'agent ?");
const col = (x, head, color, items) => {
  s.addShape(pres.ShapeType.roundRect, { x, y: 1.4, w: 4.2, h: 2.8, rectRadius: 0.1, fill: { color: "FFFFFF" }, line: { color, width: 1.5 } });
  s.addText(head, { x, y: 1.4, w: 4.2, h: 0.5, align: "center", bold: true, fontSize: 18, color: "FFFFFF", fill: { color }, isTextBox: true });
  s.addText(items.map((t, i) => ({ text: t, options: { bullet: true, breakLine: i < items.length - 1 } })),
    { x: x + 0.2, y: 2.05, w: 3.8, h: 2.0, fontSize: 15, color: "14213D", paraSpaceAfter: 6, isTextBox: true, valign: "top" });
};
col(0.6, "Sans test", "D64545", ["Régressions après modification", "Réponses imprévues", "Erreurs détectées en production", "Comportement non maîtrisé"]);
col(5.2, "Avec test", "1F9D55", ["Validation automatique", "Détection précoce des erreurs", "Comportement stable", "Déploiements plus sûrs"]);
s.addText("Tester avant de déployer", { x: 2.5, y: 4.45, w: 5, h: 0.5, align: "center", bold: true, fontSize: 18, color: "1F3A5F", fill: { color: "DDEBF5" }, isTextBox: true });

// 3. architecture
s = content("Architecture");
s.addImage({ path: "docs/architecture.png", x: 1.9, y: 1.2, w: 6.2, h: 3.5, altText: "Architecture de l'agent et du pipeline CI/CD" });
s.addText("Production : workflow Langflow · Qualité : agent Python + mocks · CI/CD : tests à chaque push", { x: 0.6, y: 4.85, w: 8.8, h: 0.35, fontSize: 12, color: "5B6478", isTextBox: true, margin: 0 });

// 3b. workflow Langflow
s = content("Workflow Langflow");
const box = (x, y, w, h, txt, c, sub) => { s.addText(sub ? [{ text: txt, options: { bold: true, fontSize: 12, breakLine: true } }, { text: sub, options: { fontSize: 9.5 } }] : txt, { x, y, w, h, fill: { color: c }, color: "FFFFFF", align: "center", valign: "middle", fontSize: 12, bold: !sub, isTextBox: true, shape: pres.ShapeType.roundRect, rectRadius: 0.08 }); };
const arrow = (x, y, w) => s.addShape(pres.ShapeType.line, { x, y, w, h: 0, line: { color: "8B97B5", width: 2, endArrowType: "triangle" } });
box(0.5, 1.35, 2.0, 0.75, "Chat Input", "1F3A5F", "question de l’élève"); arrow(2.5, 1.725, 0.4);
box(2.9, 1.35, 2.0, 0.75, "Classifieur", "2B5FD9", "intent · topic · policy"); arrow(4.9, 1.725, 0.4);
box(5.3, 1.35, 2.0, 0.75, "Smart Router", "E8871E", "2 routes");
s.addText("Route TUTORAT", { x: 0.5, y: 2.3, w: 1.8, h: 0.3, fontSize: 11, bold: true, color: "FFFFFF", fill: { color: "1F9D55" }, align: "center", isTextBox: true });
[["Agent Tuteur", "+ Recherche de cours"], ["Formateur JSON", "7 champs du contrat"], ["Journal DB", "education_executions"], ["Chat Output", "réponse finale"]].forEach(([a, b], i) => {
  const x = 0.5 + i * 2.3; box(x, 2.7, 1.9, 0.8, a, "1F3A5F", b); if (i < 3) arrow(x + 1.9, 3.1, 0.4); });
s.addText("Route REFUS / HORS CADRE", { x: 0.5, y: 3.7, w: 2.4, h: 0.3, fontSize: 11, bold: true, color: "FFFFFF", fill: { color: "D64545" }, align: "center", isTextBox: true });
box(0.5, 4.1, 4.2, 0.7, "JSON status = refused", "D64545", "triche · injection · hors cadre · entrée invalide"); arrow(4.7, 4.45, 0.4);
box(5.1, 4.1, 1.9, 0.7, "Chat Output", "1F3A5F", "aucun appel d’outil");
s.addText("Export : Correction_AI_Education.json", { x: 7.2, y: 4.2, w: 2.3, h: 0.5, fontSize: 11, color: "5B6478", isTextBox: true, margin: 0, valign: "middle" });

// 4. types de tests
s = content("Les 4 types de tests (+ mocks et non-régression)");
const cards = [["Format", "Schéma JSON, champs, types", "DDEBF5", 5], ["Intégration", "Enchaînement agent → outils", "DDF3E0", 5],
  ["Policy", "Triche, injection, confidentialité", "FBF1CC", 6], ["Mauvaise entrée", "Vide, None, ID/niveau invalides", "F9DAD5", 6]];
cards.forEach(([t, d, f, n], i) => {
  const x = 0.6 + i * 2.25;
  s.addShape(pres.ShapeType.roundRect, { x, y: 1.4, w: 2.05, h: 2.7, rectRadius: 0.08, fill: { color: f }, line: { color: f } });
  s.addText(String(n), { x, y: 1.5, w: 2.05, h: 0.8, align: "center", fontSize: 40, bold: true, color: "1F3A5F", isTextBox: true });
  s.addText(t, { x, y: 2.3, w: 2.05, h: 0.45, align: "center", fontSize: 16, bold: true, color: "1F3A5F", isTextBox: true });
  s.addText(d, { x: x + 0.1, y: 2.8, w: 1.85, h: 1.1, align: "center", fontSize: 12, color: "14213D", isTextBox: true, valign: "top" });
});
s.addText("+ 5 tests de mocks (pannes) et 1 test de non-régression sur 3 cas de référence", { x: 0.6, y: 4.4, w: 8.8, h: 0.4, fontSize: 14, color: "1F3A5F", bold: true, isTextBox: true, margin: 0 });

// 5. mocks
s = content("Mocking des outils");
const sc = [["success", "Cours / progression retournés", "1F9D55", "ok"], ["error_500", "Erreur 500 → retry x1", "D64545", "degraded"],
  ["timeout", "Timeout → retry x1", "E8871E", "degraded"], ["empty", "Aucun résultat", "5B6478", "ok + message"]];
sc.forEach(([n, d, c, r], i) => {
  const y = 1.4 + i * 0.85;
  s.addText(n, { x: 0.6, y, w: 2.2, h: 0.65, fontSize: 16, bold: true, color: "FFFFFF", fill: { color: c }, align: "center", isTextBox: true });
  s.addText(d, { x: 3.0, y, w: 3.8, h: 0.65, fontSize: 15, color: "14213D", valign: "middle", isTextBox: true });
  s.addText("→ " + r, { x: 6.9, y, w: 2.5, h: 0.65, fontSize: 15, bold: true, color: "1F3A5F", valign: "middle", isTextBox: true });
});
s.addText("Rapide, déterministe, sans réseau : on simule ce qui est rare ou difficile à reproduire.", { x: 0.6, y: 4.85, w: 8.8, h: 0.35, fontSize: 13, color: "5B6478", isTextBox: true, margin: 0 });

// 6. pipeline
s = content("Pipeline CI/CD agentique");
[["Push GitHub", "Code, prompts, workflows versionnés"], ["Exécution des tests", "pytest : 28 cas"], ["Validation (build)", "Rapport + dashboard"], ["Déploiement", "Seulement si tout est vert"]]
  .forEach(([t, d], i) => {
    const x = 0.6 + i * 2.3, colr = ["1F3A5F", "2B5FD9", "E8871E", "1F9D55"][i];
    s.addShape(pres.ShapeType.ellipse, { x: x + 0.65, y: 1.5, w: 0.8, h: 0.8, fill: { color: colr }, line: { color: colr } });
    s.addText(String(i + 1), { x: x + 0.65, y: 1.5, w: 0.8, h: 0.8, align: "center", valign: "middle", fontSize: 24, bold: true, color: "FFFFFF", isTextBox: true, margin: 0 });
    if (i < 3) s.addShape(pres.ShapeType.line, { x: x + 1.55, y: 1.9, w: 1.3, h: 0, line: { color: "B0B8C8", width: 2, endArrowType: "triangle" } });
    s.addText(t, { x, y: 2.5, w: 2.1, h: 0.45, align: "center", bold: true, fontSize: 15, color: "1F3A5F", isTextBox: true });
    s.addText(d, { x, y: 2.95, w: 2.1, h: 0.8, align: "center", fontSize: 12, color: "14213D", isTextBox: true, valign: "top" });
  });
s.addText("Un comportement validé hier doit rester valide demain", { x: 1.2, y: 4.2, w: 7.6, h: 0.55, align: "center", bold: true, fontSize: 18, color: "1F3A5F", fill: { color: "DDEBF5" }, isTextBox: true });

// 7. résultats
s = content("Résultats de la suite de tests");
[[rep.total, "tests"], [rep.passed, "réussis"], [rep.failed, "échoués"], [rep.rate + " %", "succès"]].forEach(([v, l], i) => {
  const x = 0.6 + i * 1.2;
  s.addText([{ text: String(v), options: { fontSize: 26, bold: true, color: i === 2 && rep.failed ? "D64545" : "1F3A5F", breakLine: true } }, { text: l, options: { fontSize: 12, color: "5B6478" } }],
    { x, y: 1.4, w: 1.1, h: 1.1, align: "center", valign: "middle", fill: { color: "F4F6FA" }, isTextBox: true });
});
s.addText("Pipeline : build passing", { x: 0.6, y: 2.75, w: 4.7, h: 0.4, align: "center", bold: true, fontSize: 14, color: "FFFFFF", fill: { color: rep.failed ? "D64545" : "1F9D55" }, isTextBox: true });
const cats = Object.keys(rep.categories);
s.addChart(pres.charts.BAR, [{ name: "Tests réussis", labels: cats, values: cats.map(k => rep.categories[k].passed) }],
  { x: 5.4, y: 1.3, w: 4.2, h: 3.7, barDir: "bar", chartColors: ["1F9D55"], showTitle: true, title: "Réussis par catégorie", titleFontSize: 13, titleColor: "1F3A5F",
    showValue: true, dataLabelPosition: "outEnd", dataLabelFontSize: 11, showLegend: false, catAxisLabelFontSize: 11, valAxisLabelFontSize: 10,
    catAxisLabelFontFace: "+mn-lt", valAxisLabelFontFace: "+mn-lt", dataLabelFontFace: "+mn-lt", valGridLine: { color: "E3E6EE", size: 0.5 }, catGridLine: { style: "none" }, catAxisOrientation: "maxMin" });

// 8. dashboard
s = content("Dashboard");
s.addShape(pres.ShapeType.roundRect, { x: 0.6, y: 1.35, w: 2.3, h: 3.5, rectRadius: 0.08, fill: { color: "1F3A5F" }, line: { color: "1F3A5F" } });
s.addImage({ path: "assets/logo_icon.png", x: 0.75, y: 1.5, w: 0.45, h: 0.45, altText: "Logo" });
s.addText([{ text: "AI ", options: { color: "FFFFFF" } }, { text: "Education", options: { color: "F2B90F" } }], { x: 1.25, y: 1.5, w: 1.6, h: 0.45, fontSize: 13, bold: true, isTextBox: true, margin: 0, valign: "middle" });
["Vue d’ensemble", "Tester l’agent", "Statistiques", "Tests", "Mocks", "Workflow", "Terminal"].forEach((m, i) => {
  s.addText(m, { x: 0.7, y: 2.05 + i * 0.39, w: 2.1, h: 0.34, fontSize: 12, color: "FFFFFF", isTextBox: true, margin: [0, 0, 0, 8], valign: "middle", fill: i === 0 ? { color: "3A5A87" } : undefined });
});
const D8 = [["Menu", "7 pages, mode clair / sombre"], ["Formulaire", "Question, élève, niveau, scénario de mock"], ["Graphiques", "Anneau de réussite, barres par catégorie et par statut"], ["Statistiques", "Requêtes, durée des tests, historique"]];
D8.forEach(([a, b], i) => {
  const y = 1.35 + i * 0.9;
  s.addText(a, { x: 3.3, y, w: 1.8, h: 0.75, fontSize: 15, bold: true, color: "FFFFFF", fill: { color: ["2B5FD9", "1F9D55", "E8871E", "1F3A5F"][i] }, align: "center", valign: "middle", isTextBox: true });
  s.addText(b, { x: 5.25, y, w: 4.2, h: 0.75, fontSize: 14, color: "14213D", valign: "middle", isTextBox: true });
});
s.addText("Un seul fichier HTML, régénéré à chaque exécution des tests", { x: 3.3, y: 4.95, w: 6.1, h: 0.3, fontSize: 12, color: "5B6478", isTextBox: true, margin: 0 });

// 9. terminal
s = content("Démo terminal");
s.addShape(pres.ShapeType.roundRect, { x: 0.6, y: 1.3, w: 8.8, h: 3.3, rectRadius: 0.06, fill: { color: "0B1220" }, line: { color: "0B1220" } });
const T = [["$ python main.py \"Donne un quiz python\" --scenario timeout", "7BD88F"], ["{ \"status\": \"degraded\", \"intent\": \"quiz\", ... }", "D6E2FF"], ["$ pytest tests -v", "7BD88F"], ["tests/test_agent.py::test_11_refuse_cheating PASSED", "D6E2FF"], ["tests/test_agent.py::test_24_timeout_retries_once PASSED", "D6E2FF"], ["...", "8B97B5"], ["====== 28 passed ======", "7BD88F"]];
s.addText(T.map(([l, c], i) => ({ text: l, options: { color: c, breakLine: i < T.length - 1 } })), { x: 0.8, y: 1.45, w: 8.4, h: 3.0, fontFace: "Consolas", fontSize: 13, valign: "top", paraSpaceAfter: 6, isTextBox: true });
s.addText("python main.py · pytest tests -v · python run_report.py", { x: 0.6, y: 4.8, w: 8.8, h: 0.35, fontSize: 13, bold: true, color: "1F3A5F", isTextBox: true, margin: 0 });

// 10. livrables
s = content("Livrables");
const L = ["Workflow final : export JSON Langflow + documentation (docx)", "Suite de 28 tests avec rapport (JSON / MD / dashboard)", "Pipeline CI GitHub Actions (badge vert dans le repo)", "Documentation des mocks", "Code : main.py, mocks.py, notebook.ipynb", "Dashboard HTML (menu, formulaire, graphiques, terminal) et logo"];
s.addText(L.map((t, i) => ({ text: t, options: { bullet: true, breakLine: i < L.length - 1 } })), { x: 0.7, y: 1.4, w: 8.6, h: 2.9, fontSize: 18, color: "14213D", paraSpaceAfter: 8, valign: "top", isTextBox: true });
s.addText("Tester avant de déployer.", { x: 0.7, y: 4.4, w: 8.6, h: 0.5, fontSize: 20, bold: true, color: "E8871E", isTextBox: true, margin: 0 });

pres.writeFile({ fileName: "docs/presentation.pptx" }).then(() => applyTheme("docs/presentation.pptx", THEME)).then(() => console.log("pptx ok"));
