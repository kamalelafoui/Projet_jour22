const fs = require("fs");
const { Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, WidthType,
  ShadingType, ImageRun, AlignmentType, LevelFormat, PageBreak, BorderStyle } = require("docx");
const rep = JSON.parse(fs.readFileSync("reports/report.json", "utf8"));
const W = 9360; // A4 content width approx with 1" margins on Letter; we use A4 below
const P = (t, o = {}) => new Paragraph({ spacing: { after: 120 }, ...o, children: [new TextRun({ text: t, ...(o.run || {}) })] });
const H1 = t => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)] });
const H2 = t => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(t)] });
const B = t => new Paragraph({ numbering: { reference: "b", level: 0 }, children: [new TextRun(t)] });
const border = { style: BorderStyle.SINGLE, size: 4, color: "BFC7D5" };
const borders = { top: border, bottom: border, left: border, right: border };
function table(widths, header, rows) {
  const total = widths.reduce((a, b) => a + b, 0);
  const cell = (t, w, h) => new TableCell({ borders, width: { size: w, type: WidthType.DXA },
    shading: h ? { fill: "1F3A5F", type: ShadingType.CLEAR, color: "auto" } : undefined,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: [new Paragraph({ children: [new TextRun({ text: String(t), bold: h, color: h ? "FFFFFF" : "14213D", size: 20 })] })] });
  return new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: widths,
    rows: [new TableRow({ tableHeader: true, children: header.map((t, i) => cell(t, widths[i], true)) }),
      ...rows.map(r => new TableRow({ children: r.map((t, i) => cell(t, widths[i], false)) }))] });
}
const img = fs.readFileSync("docs/architecture.png");
const CW = 9026; // A4 with 1" margins
const logo = fs.readFileSync("assets/logo.png");
const children = [
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 1200 }, children: [new ImageRun({ type: "png", data: logo, transformation: { width: 360, height: 77 }, altText: { title: "Logo", description: "Logo AI Education", name: "logo" } })] }),
  new Paragraph({ spacing: { before: 1200, after: 200 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "AI Education", bold: true, size: 64, color: "1F3A5F" })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 },
    children: [new TextRun({ text: "Tests automatisés & CI/CD agentique", size: 36, color: "C28A00" })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 },
    children: [new TextRun({ text: "Mini-projet — Correction finale · Jour 22", size: 26 })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Version " + rep.generated.slice(0, 10), size: 22, color: "5B6478" })] }),
  new Paragraph({ children: [new PageBreak()] }),

  H1("1. Objectif"),
  P("Industrialiser un agent tuteur « AI Education » afin de garantir sa qualité après chaque modification : tests métier, mocks des outils, suite de non-régression et pipeline GitHub Actions."),
  P("Principe directeur : un comportement validé hier doit rester valide demain."),

  H1("2. Architecture"),
  new Paragraph({ alignment: AlignmentType.CENTER, children: [new ImageRun({ type: "png", data: img, transformation: { width: 560, height: 316 },
    altText: { title: "Architecture", description: "Architecture de l'agent AI Education et du pipeline CI/CD", name: "architecture" } })] }),
  P("En production, le workflow Langflow classe la demande, applique la policy, puis passe par l'agent tuteur et le formatage JSON. En qualité, l'agent Python (même logique) est testé avec des mocks (28 tests), exécutés à chaque push par la CI GitHub Actions, qui produit le rapport et le dashboard.", { run: { italics: true } }),
  table([2400, 6626], ["Composant", "Rôle"], [
    ["main.py", "Agent : validation, policy, routage, retry, réponse JSON avec trace"],
    ["mocks.py", "Mocks API Cours et API Progression (4 scénarios)"],
    ["tests/test_agent.py", "28 tests métier, compatibles unittest et pytest"],
    ["tests/golden.json", "Cas de référence pour la non-régression"],
    ["run_report.py", "Exécute les tests, produit report.json, report.md et dashboard.html"],
    ["Correction_AI_Education.json", "Export du workflow Langflow (9 composants, importable dans Langflow)"],
    ["notebook.ipynb", "Démonstration pas à pas"],
    [".github/workflows/ci.yml", "Pipeline CI : tests, validation, déploiement"],
  ]),

  H2("Workflow Langflow"),
  P("Le fichier Correction_AI_Education.json suit le même schéma que l’agent Météo du cours : classification, routage, agent avec outil, formatage JSON, journalisation."),
  table([2700, 6326], ["Composant", "Rôle"], [
    ["Chat Input (Élève)", "Reçoit la question de l’élève"],
    ["OpenRouter (Classifieur)", "Modèle du routeur ; prompt de classification : intent, topic, policy_flag, valid_input"],
    ["Smart Router", "2 routes : TUTORAT, ou REFUS / ENTRÉE INVALIDE / HORS CADRE (policy)"],
    ["Chat Output (refus)", "Renvoie directement un JSON status = refused, sans appel d’outil"],
    ["Recherche de cours", "Outil de l’agent (en test, remplacé par un mock)"],
    ["Agent Tuteur", "Explique, crée un quiz, retry ×1 puis service indisponible"],
    ["OpenRouter (Formateur JSON)", "Produit les 7 champs du contrat de sortie"],
    ["Journal des exécutions (DB)", "Insère le JSON dans la collection education_executions"],
    ["Chat Output", "Réponse finale"],
  ]),
  P("Avant l’import : renseigner dans Langflow la variable Openrouter, la clé du modèle de l’agent et l’URI de la base. Aucun identifiant n’est stocké dans le fichier.", { run: { italics: true } }),

  H1("3. Contrat de sortie (format)"),
  P("Chaque réponse est un objet JSON avec les champs obligatoires suivants :"),
  table([2000, 1800, 5226], ["Champ", "Type", "Description"], [
    ["status", "string", "ok · refused · error · degraded"],
    ["intent", "string", "explain · quiz · progress · policy · invalid"],
    ["answer", "string", "Texte destiné à l'élève"],
    ["level", "string", "primaire · college · lycee · universite"],
    ["quiz", "liste", "Questions : q, choices, answer_index"],
    ["sources", "liste", "Identifiants de cours ou d'élève utilisés"],
    ["trace", "liste", "Appels d'outils : tool, attempt, ok, error"],
  ]),

  H1("4. Policy (règles métier)"),
  B("Refus de toute aide à la triche (réponses d'examen)."),
  B("Refus des tentatives d'injection de prompt (« ignore tes instructions »)."),
  B("Refus des demandes hors cadre éducatif."),
  B("Confidentialité : un élève ne peut pas consulter la progression d'un autre."),
  B("Les refus ne déclenchent aucun appel d'outil. La détection ignore casse et accents."),

  H1("5. Documentation des mocks"),
  P("Certains scénarios sont rares ou difficiles à reproduire avec des services réels. Les mocks simulent succès, pannes et comportements inattendus sans réseau, de façon rapide et déterministe."),
  table([1800, 2300, 2300, 2626], ["Scénario", "API Cours", "API Progression", "Comportement attendu de l'agent"], [
    ["success", "Retourne le cours", "Retourne la progression", "status = ok"],
    ["error_500", "Lève ToolError", "Lève ToolError", "Retry x1 puis status = degraded"],
    ["timeout", "Lève ToolTimeout", "Lève ToolTimeout", "Retry x1 puis status = degraded"],
    ["empty", "Retourne None", "Retourne None", "status = ok, message « Aucun cours »"],
    ["FlakyCourseAPI", "Échoue au 1er appel", "—", "Le retry réussit : status = ok, 2 appels tracés"],
  ]),
  P(""),
  P("Données simulées : 5 cours (fractions, équations, Python, photosynthèse, grammaire), une banque de quiz et 3 élèves (S001, S002, S003). Chaque mock compte ses appels (attribut calls) pour vérifier les enchaînements."),

  H1("6. Suite de tests"),
  P(`${rep.total} tests au total (exigence : ≥ 20), répartis en 6 catégories :`),
  table([2600, 1500, 1500, 3426], ["Catégorie", "Tests", "Réussis", "Objectif"], [
    ["Format", 5, 5, "Schéma JSON, champs obligatoires, types"],
    ["Intégration", 5, 5, "Enchaînement agent → outils, trace"],
    ["Policy", 6, 6, "Triche, injection, confidentialité"],
    ["Mauvaise entrée", 6, 6, "Vide, None, niveau/ID invalides, trop long"],
    ["Mocks", 5, 5, "Panne 500, timeout, retry, vide"],
    ["Non-régression", 1, 1, "3 cas de référence (golden.json)"],
  ].map(r => { const c = rep.categories[r[0]]; return [r[0], c.passed + c.failed, c.passed, r[3]]; })),
  P(""),
  H2("Liste détaillée"),
  table([900, 5726, 2400], ["N°", "Test", "Catégorie"], rep.tests.map(t => [t.name.split("_")[1], t.name.split("_").slice(2).join(" "), t.category])),

  H1("7. Pipeline CI/CD"),
  table([2400, 6626], ["Étape", "Action"], [
    ["Push sur GitHub", "Déclenche le workflow à chaque push et pull request"],
    ["Exécution des tests", "pytest tests -v (28 cas)"],
    ["Validation (build)", "run_report.py : rapport, dashboard ; échec si un test est rouge"],
    ["Déploiement", "Job conditionné au succès des tests et à la branche main (simulé)"],
  ]),
  P(""),
  P("Pour obtenir le badge vert : créer le dépôt, pousser le code, puis remplacer <votre-compte> dans le badge du README."),

  H1("8. Dashboard (dashboard.html)"),
  P("Fichier HTML unique, sans dépendance, qui suit le mode clair ou sombre. Il est régénéré par run_report.py à chaque exécution des tests."),
  table([2400, 6626], ["Page du menu", "Contenu"], [
    ["Vue d’ensemble", "Indicateurs (tests, réussis, échoués, taux), état du pipeline, anneau de réussite, tests par catégorie"],
    ["Tester l’agent", "Formulaire : question, élève, niveau, scénario de mock, case « progression d’un autre élève » ; affiche statut, réponse, quiz et JSON avec trace"],
    ["Statistiques", "Requêtes par statut (graphique en barres), durée des tests, historique des requêtes de la session"],
    ["Tests", "Tableau des 28 tests avec filtre par catégorie"],
    ["Mocks", "Les 4 scénarios simulés et la réaction attendue"],
    ["Workflow", "Schéma du workflow Langflow (Correction_AI_Education.json) et liste de ses 9 composants"],
    ["Terminal", "Simulation des commandes du projet dans le navigateur (voir section 9)"],
  ]),
  P(""),
  P("Le formulaire exécute une copie JavaScript de la logique de main.py. Si l’agent Python est modifié, cette copie doit être mise à jour.", { run: { italics: true } }),

  H1("9. Utilisation en terminal"),
  P("Prérequis : Python 3.10 ou plus récent et Git. Sous Windows, remplacer python3 par python ou py."),
  table([4300, 4726], ["Commande", "Effet"], [
    ["python main.py \"Explique-moi les fractions\"", "Exécute l’agent (options : --student, --level, --scenario)"],
    ["python main.py \"Donne un quiz python\" --scenario timeout", "Simule une panne : retry puis status degraded"],
    ["python -m unittest discover -s tests -v", "Lance les 28 tests sans rien installer"],
    ["pytest tests -v", "Lance les tests comme la CI (pip install pytest)"],
    ["python run_report.py", "Tests + reports/ + dashboard.html"],
    ["git init, git add ., git commit, git push", "Publie sur GitHub et déclenche le pipeline CI"],
  ]),

  H1("10. Résultats"),
  P(`${rep.passed}/${rep.total} tests réussis (${rep.rate} %) — rapport généré le ${rep.generated}. Le détail visuel est disponible dans dashboard.html (section 8).`),

  H1("11. Livrables"),
  B("Workflow final : Correction_AI_Education.json (export Langflow) et cette documentation."),
  B("Suite de tests (28 cas) avec rapport : tests/, reports/report.json, reports/report.md."),
  B("Pipeline CI fonctionnel : .github/workflows/ci.yml (badge vert après premier push)."),
  B("Documentation des mocks : section 5."),
  B("Code et démonstration : main.py, mocks.py, notebook.ipynb, présentation PPTX."),
  B("Dashboard : dashboard.html (menu, formulaire, graphiques, terminal)."),
  B("Identité visuelle : logo (SVG et PNG) dans assets/."),
];
const doc = new Document({
  styles: { default: { document: { run: { font: "Calibri", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, color: "1F3A5F" }, paragraph: { spacing: { before: 360, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, color: "C28A00" }, paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 } }] },
  numbering: { config: [{ reference: "b", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] }] },
  sections: [{ properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } }, children }],
});
Packer.toBuffer(doc).then(b => { fs.writeFileSync("docs/documentation.docx", b); console.log("docx ok"); });
