# Rapport de tests — AI Education
_Généré le 2026-10-28 11:26_

**28/28 tests réussis (100.0 %)**

| Catégorie | Réussis | Échoués |
|---|---|---|
| Format | 5 | 0 |
| Intégration | 5 | 0 |
| Policy | 6 | 0 |
| Mauvaise entrée | 6 | 0 |
| Mocks | 5 | 0 |
| Non-régression | 1 | 0 |

| Test | Catégorie | Statut | ms |
|---|---|---|---|
| test_01_schema_explain | Format | ✅ | 0.05 |
| test_02_schema_quiz | Format | ✅ | 0.03 |
| test_03_quiz_answer_index_valid | Format | ✅ | 0.02 |
| test_04_output_is_json_serializable | Format | ✅ | 0.1 |
| test_05_validator_detects_missing_field | Format | ✅ | 0.01 |
| test_06_explain_calls_course_api | Intégration | ✅ | 0.03 |
| test_07_progress_calls_progress_api_only | Intégration | ✅ | 0.02 |
| test_08_trace_records_tool_call | Intégration | ✅ | 0.02 |
| test_09_unknown_topic_graceful | Intégration | ✅ | 0.02 |
| test_10_new_student_no_progress | Intégration | ✅ | 0.02 |
| test_11_refuse_cheating | Policy | ✅ | 0.02 |
| test_12_refuse_prompt_injection | Policy | ✅ | 0.01 |
| test_13_refuse_off_topic | Policy | ✅ | 0.01 |
| test_14_refuse_other_student_progress | Policy | ✅ | 0.01 |
| test_15_no_tool_call_when_refused | Policy | ✅ | 0.01 |
| test_16_case_and_accents_do_not_bypass_policy | Policy | ✅ | 0.01 |
| test_17_empty_question | Mauvaise entrée | ✅ | 0.04 |
| test_18_none_request | Mauvaise entrée | ✅ | 0.02 |
| test_19_invalid_level | Mauvaise entrée | ✅ | 0.01 |
| test_20_invalid_student_id | Mauvaise entrée | ✅ | 0.01 |
| test_21_question_too_long | Mauvaise entrée | ✅ | 0.01 |
| test_22_wrong_type_question | Mauvaise entrée | ✅ | 0.01 |
| test_23_error_500_degraded | Mocks | ✅ | 0.03 |
| test_24_timeout_retries_once | Mocks | ✅ | 0.06 |
| test_25_retry_recovers | Mocks | ✅ | 0.02 |
| test_26_empty_scenario | Mocks | ✅ | 0.02 |
| test_27_progress_outage_degraded | Mocks | ✅ | 0.02 |
| test_28_golden_cases | Non-régression | ✅ | 0.15 |
