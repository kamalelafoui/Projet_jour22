"""Exécute la suite de tests et produit : reports/report.json, reports/report.md, dashboard.html.
Code retour != 0 si au moins un test échoue (utilisé par la CI GitHub Actions).
"""
import json
import os
import sys
import time
import unittest
from datetime import datetime

ROOT = os.path.dirname(os.path.abspath(__file__))
CATEGORIES = {"TestFormat": "Format", "TestIntegration": "Intégration", "TestPolicy": "Policy",
              "TestBadInput": "Mauvaise entrée", "TestMocks": "Mocks", "TestRegression": "Non-régression"}


class Collector(unittest.TextTestResult):
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.rows, self._t = [], 0

    def startTest(self, test):
        super().startTest(test)
        self._t = time.perf_counter()

    def _add(self, test, status, msg=""):
        cls = type(test).__name__
        self.rows.append({"name": test._testMethodName, "category": CATEGORIES.get(cls, cls),
                          "doc": (getattr(test, test._testMethodName).__doc__ or "").strip(),
                          "status": status, "ms": round((time.perf_counter() - self._t) * 1000, 2),
                          "message": msg[-300:]})

    def addSuccess(self, test):
        super().addSuccess(test); self._add(test, "passed")

    def addFailure(self, test, err):
        super().addFailure(test, err); self._add(test, "failed", self._exc_info_to_string(err, test))

    def addError(self, test, err):
        super().addError(test, err); self._add(test, "failed", self._exc_info_to_string(err, test))


def build():
    sys.path.insert(0, ROOT)
    suite = unittest.defaultTestLoader.discover(os.path.join(ROOT, "tests"))
    runner = unittest.TextTestRunner(resultclass=Collector, verbosity=0, stream=open(os.devnull, "w"))
    res = runner.run(suite)
    rows = sorted(res.rows, key=lambda r: r["name"])
    cats = {}
    for r in rows:
        c = cats.setdefault(r["category"], {"passed": 0, "failed": 0})
        c[r["status"]] += 1
    total, passed = len(rows), sum(r["status"] == "passed" for r in rows)
    return {"generated": datetime.now().strftime("%Y-%m-%d %H:%M"), "total": total, "passed": passed,
            "failed": total - passed, "rate": round(100 * passed / total, 1) if total else 0,
            "categories": cats, "tests": rows}


def write_md(rep, path):
    lines = [f"# Rapport de tests — AI Education", f"_Généré le {rep['generated']}_", "",
             f"**{rep['passed']}/{rep['total']} tests réussis ({rep['rate']} %)**", "",
             "| Catégorie | Réussis | Échoués |", "|---|---|---|"]
    lines += [f"| {k} | {v['passed']} | {v['failed']} |" for k, v in rep["categories"].items()]
    lines += ["", "| Test | Catégorie | Statut | ms |", "|---|---|---|---|"]
    lines += [f"| {t['name']} | {t['category']} | {'✅' if t['status']=='passed' else '❌'} | {t['ms']} |"
              for t in rep["tests"]]
    open(path, "w", encoding="utf-8").write("\n".join(lines) + "\n")


def main():
    rep = build()
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(rep, open(os.path.join(ROOT, "reports", "report.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    write_md(rep, os.path.join(ROOT, "reports", "report.md"))
    tpl = open(os.path.join(ROOT, "dashboard_template.html"), encoding="utf-8").read()
    open(os.path.join(ROOT, "dashboard.html"), "w", encoding="utf-8").write(
        tpl.replace("/*__DATA__*/null", json.dumps(rep, ensure_ascii=False)))
    print(f"{rep['passed']}/{rep['total']} tests réussis ({rep['rate']} %)")
    return 0 if rep["failed"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
