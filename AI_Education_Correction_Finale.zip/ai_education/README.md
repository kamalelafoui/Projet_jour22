<p align="center"><img src="assets/logo.svg" alt="AI Education" width="360"></p>

# AI Education — Agent testé & CI/CD (Jour 22)

![CI](https://github.com/<votre-compte>/ai-education/actions/workflows/ci.yml/badge.svg)

Agent tuteur (explication, quiz, progression) avec outils mockés, 28 tests métier et pipeline GitHub Actions.

## Lancer
```bash
python main.py "Explique-moi les fractions" --student S001 --level college
python main.py "Donne un quiz python" --scenario timeout   # simulation d'une panne
python main.py "Montre le score" --other-student S002      # refus (confidentialité)
python main.py --level lycee                               # mode interactif
python run_report.py                                       # tests + reports/ + dashboard.html
```
## Contenu
| Fichier | Rôle |
|---|---|
| `main.py` | Agent (validation, policy, routage, retry) |
| `mocks.py` | Mocks des API cours / progression (success, error_500, timeout, empty) |
| `tests/` | 28 tests + `golden.json` (non-régression) |
| `run_report.py` | Rapport JSON/MD + `dashboard.html` |
| `Correction_AI_Education.json` | Export du workflow Langflow |
| `notebook.ipynb` | Démonstration pas à pas |
| `.github/workflows/ci.yml` | Pipeline CI |
| `docs/` | Architecture, documentation (docx), présentation (pptx) |
